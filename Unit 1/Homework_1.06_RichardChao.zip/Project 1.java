public class Mississippi {
public static void main(String[] args) {
        m();
        i();
        s();
        s();
        i();
        s();
        s();
        i();
        p();
        p();
        i();
}
public static void m(){
        System.out.println("M     M\nMM   MM\nM M M M\nM  M  M\nM     M\nM     M\nM     M");
}
public static void i(){
        System.out.println("IIIII\n  I  \n  I  \n  I  \n  I  \n  I  \nIIIII");
}
public static void s(){
        System.out.println(" SSSSS\n S     S\nS\n SSSSS\n      S\nS     S\n SSSSS\n");
}
public static void p(){
        System.out.println("PPPPPP\nP     P\nP     PPPPPPP\nP\nP\nP");
}
}
