public class OldLady {
public static void main(String[] args) {
        fly();
        dontdie();
        spider();
        dontdie();
        bird();
        dontdie();
        cat();
        dontdie();
        dog();
        dontdie();
        tragic();
}
public static void dontdie(){
        System.out.println("I don't know why she swallowed that fly,\nPerhaps she’ll die.\n");
}
public static void fly(){
        System.out.println("There was an old lady who swallowed a fly.");
}
public static void spider(){
        System.out.println("There was an old lady who swallowed a spider,\nThat wriggled and iggled and jiggled inside her.\nShe swallowed the spider to catch the fly,");
}
public static void bird(){
        System.out.println("There was an old lady who swallowed a bird,\nHow absurd to swallow a bird.\nShe swallowed the bird to catch the spider,\nShe swallowed the spider to catch the fly,");
}
public static void cat(){
        System.out.println("There was an old lady who swallowed a cat,\nImagine that to swallow a cat.\nShe swallowed the cat to catch the bird,\nShe swallowed the bird to catch the spider,\nShe swallowed the spider to catch the fly,");
}
public static void dog(){
        System.out.println("There was an old lady who swallowed a dog,\nWhat a hog to swallow a dog.\nShe swallowed the dog to catch the cat,\nShe swallowed the cat to catch the bird,\nShe swallowed the bird to catch the spider,\nShe swallowed the spider to catch the fly,");
}
public static void tragic(){
        System.out.println("There was an old lady who swallowed a horse,\nShe died of course.");
}
}
